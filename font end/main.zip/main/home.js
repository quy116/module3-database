function change() {
  var div2 = document.getElementById("div2");
}
